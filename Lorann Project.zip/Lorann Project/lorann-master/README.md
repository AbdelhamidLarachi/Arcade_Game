# JPU-BlankProject
Base de démarrage pour le projet Java/POO/UML des 1ières années Exia-Cesi
=======
# lorann
lorann

# Map Spec

- B : bone.png
- K : crystal_ball.png
- H : horizontal_bone.png
- V : vertical_bone.png
- C : gate_closed.png
- O : gate_open.png
- P : purse.png
- L : lorann_XX.png
- [1-4] : monster_{}.png

