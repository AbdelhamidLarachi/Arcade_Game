package model;

/**
 * The Class Entity.
 *
 */
abstract class Entity {

}
