package model;

/**
 * The Class EntityScore.
 *
 */
abstract public class EntityScore {
}
