package model;

/**
 * The Class GetHighScore.
 *
 */
class GetHighscore extends EntityScore {
    /**
     * Instantiates a new GetHighscore.
     */
    public GetHighscore() {

    }
}

