package model.motionless;


/** Class used to create the score */
public class Score extends Empty {
}
