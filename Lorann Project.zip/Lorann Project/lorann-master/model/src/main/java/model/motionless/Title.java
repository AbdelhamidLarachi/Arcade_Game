package model.motionless;


/** Class used to create the title */
public class Title extends Empty {
}
