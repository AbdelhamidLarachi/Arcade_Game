package model;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class DBPropertiesTest {

    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testGetUrl() throws Exception {

    }

    @Test
    public void testGetLogin() throws Exception {

    }

    @Test
    public void testGetPassword() throws Exception {

    }
}