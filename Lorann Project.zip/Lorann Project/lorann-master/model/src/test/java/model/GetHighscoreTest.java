package model;

import org.junit.After;
import org.junit.Before;

import static org.junit.Assert.*;

/**
 */
public class GetHighscoreTest {
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

}